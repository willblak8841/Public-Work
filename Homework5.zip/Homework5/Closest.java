import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Closest {

    Node head;
    Node[][] grid = new Node[1000][1000];
    static class Node {

            double x;
            double y;
            Node next;


            Node(double keyx, double keyy, Node next){
                    x = keyx;
                    y = keyy;
                    next = null;
            }
            
            public boolean hasNext()
            {
            	if(this.next == null) {
            	return false;
            }
            return true;
            }
    }
    public static void main(String [] args) {
    		
    	   File f = new File("points.txt");
    	    
    	    try {
    	      Scanner sk = new Scanner(f);
    	        
    	      Closest obj = new Closest();
    	    
    	      
    	      while (sk.hasNext()) {
    	        double x = sk.nextDouble();
    	        double y = sk.nextDouble();
    	        obj.insert(x,y);      
    	      }
    	      
          
    	    } catch (FileNotFoundException e) {
    	        System.out.println("Cannot open file " + f.getAbsolutePath());
    	        System.out.println(e);
    	      } 
    }
    
    
    public Closest() {
    double distance = 1000;
    double distance2 = 1000;
    double closest1x = 0;
    double closest1y = 0;
    double closest2y = 0;
    double closest2x = 0;
    double compx = 0;
    double compy = 0;
    	for(int i = 0; i < 1000; i++) {
    			
    		for(int j = 0; j < 1000; j++) {
    		Node look = grid[i][j];
    		if(look != null) {
    		closest1x = look.x;
    		closest1y = look.y;
    			if(i == 0 && j == 0) {
    			// i + 0 j + 1
    			// i + 1 j + 0
    			// i + 1 j + 1
    				while(look.hasNext()) {
    					Node mad = grid[i][j+1];
    					while(mad.hasNext()) {
    						compx = mad.x;
    						compy = mad.y;
    						distance = close(closest1x, closest1y, compx, compy);
    						if(distance < distance2) {
    							
    							distance2 = distance;
    							closest2x = compx;
    							closest2y = compy;
    						}
    						
    						mad = mad.next;
    					}
    					look = look.next;
    					mad = grid[i][j+1];	
    					
    				}
    			}
    		
    		}
    	}
    }
    System.out.print("The two closest points are " + closest1x + " " + 
    closest1y + " and " + closest2x + " " + closest2y);
}
    	
    

    public void insert(double keyx, double keyy) {
    	
    		int b = hash(keyx);
    		int c = hash(keyy);
    		grid[b][c] = new Node(keyx, keyy, grid[b][c]);   
    		
    	
    	}
    
    public boolean find(double first, double second) {
    	 boolean flag = false;
    	    int xc = hash(first);
    	    int yc = hash(second);
    		if(grid[xc][yc] != null){
    			Node check = grid[xc][yc];
    			while(!(check.x == first && check.y == second)){
    				if(check == null){
    					return flag;
    				}
    				check = check.next;
    			}
    			flag = true;
    		}
    	
    	return flag;
    }
    
    public double sqrt(double num) {
    	
    	
    	//temporary variable  
    	double t;  
    	double sqrtroot=num/2;  
    	do   
    	{  
    	t=sqrtroot;  
    	sqrtroot=(t+(num/t))/2;  
    	}   
    	while((t-sqrtroot)!= 0);  
    	return sqrtroot;  
    	}  
    
    
    public double close(double x, double y, double x2, double y2) {
    	double math = 0;
    	
    	double a = (x2-x) * (x2-x);
    	double b = (y2-y) * (y2 - y);
    	double num = a + b;
    	math = sqrt(num);
    	return math;			
    }
    
    public int hash(double key){
    int h =0;
    h = (int) (key * 1000);
    
    return h;
    }
    
}

